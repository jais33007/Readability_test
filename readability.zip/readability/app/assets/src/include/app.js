window.$ = window.jQuery = require("jquery");

// Bootstrap
require('bootstrap/dist/css/bootstrap.css');
